dos8_EXTRA.img split into a bootable floppy set
=================================================

dos8_EXTRA.img was a 512MB raw MBR disk image (not a floppy) holding a FAT32
partition full of DOS dev tools (BCC, Lua, FreeBASIC, Free Pascal, Regina
REXX, DOJS, GEM desktop) plus some standalone utilities -- 62MB across 1400+
files. This directory replaces it with 55 standard 1.44MB floppy images that
boot for real and load everything into a RAM disk instead.

BOOT01.img
  Boot floppy (derived from dos8_BASE.img). CONFIG.SYS loads HIMEMX.EXE (XMS
  driver), TDSK.EXE (TurboDSK 2.3, freeware, official/stable release -- NOT
  the 2.42 beta, which hung during testing) as a RAM disk on drive C: sized
  to 30720 KB (30MB -- see "Why 30MB" below), and sets LASTDRIVE=Z.
  AUTOEXEC.BAT copies COMMAND.COM, XCOPY.EXE, CWSDPMI.EXE (DPMI host needed
  by the DJGPP-built tools -- Lua, FPC, DOJS) and every installer .BAT onto
  C:\, then switches the working drive/directory to C:\ (real DOS searches
  the current directory before PATH, so this keeps each install running its
  stable C:\ copy instead of re-reading a floppy that's since been swapped
  out) and shows the tool menu.

<TOOL><NN>.img  (e.g. FBASIC03.img)
  The actual content disks for each tool, one set per tool, sequentially
  numbered. Disk counts: BCC 1, LUA 1, FBASIC 18, FPC 18, REGINA 3, DOJS 9,
  GEM 3, TOOLS 1 -- 54 content disks total (55 with the boot disk).

How to run it (QEMU, recommended)
  qemu-system-i386 -fda BOOT01.img -boot a -m 128 -display sdl

  Boot, wait for the menu, then type a tool's name and press Enter. When it
  says "Insert <TOOL> disk N of M into drive [A:\]", switch to the QEMU
  monitor (Ctrl+Alt+2), swap the floppy with:
      change floppy0 /path/to/dos8_floppies/<TOOL><NN>.img
  then switch back to the display (Ctrl+Alt+1) and press a key to continue.
  Each installer reads from drive A: by default -- add a drive letter
  parameter (e.g. "REGINA D") if you've mounted a disk somewhere else.

  QEMU was worth switching to for one specific reason: it swaps floppies by
  just pointing "change floppy0" at any file, on demand, with no pre-built
  swap list -- so there's no cap on how many different disks a single boot
  session can get through. All 8 tools, all 55 disks, one boot, no
  reboots, no splitting into multiple configs. (DOSBox(-X) was tried first
  and hard-caps a single drive's pre-mounted swap list at 20 images, which
  is why earlier revisions of this disk set shipped 3 separate configs --
  that's no longer necessary.)

Why 30MB (TDSK's real limitation, not an emulator bug)
  TDSK.EXE hangs -- not slow, genuinely dead, confirmed by waiting 150s+
  with near-zero CPU use and an unchanging screen -- when asked to
  allocate more than roughly 30-32MB, REGARDLESS of how much total RAM the
  machine has. This was isolated by bisection: an 8MB or 16MB request
  booted fine even with 1024MB of total guest RAM; a 32MB request hung
  even though smaller requests on the very same machine did not. The
  ceiling is specifically about how much TDSK.EXE is ASKED to allocate,
  not the system's total memory.
  This was reproduced in THREE independent environments -- DOSBox-X, QEMU
  (a completely different, full-hardware emulator, not a DOSBox-anything
  codebase), and vanilla DOSBox 0.74.3 (a third, older, independent
  codebase) -- so it is a genuine bug/limitation in TDSK.EXE itself, not
  an emulator quirk. Vanilla DOSBox's own startup banner even says
  "Memory sizes above 31 MB are NOT recommended", which lines up almost
  exactly with what was found here.
  TDSK has no non-destructive auto-grow either: resizing the drive after
  boot (documented as its "dynamic memory allocation" feature) ERASES
  the drive's contents, so starting small and growing later doesn't avoid
  the problem -- it just moves the same slow/hanging allocation to a
  later point, after wiping whatever was already installed.
  30720 KB (30MB) was picked as a safe ceiling with margin below the
  confirmed 32MB hang point. Each tool grouping's actual data need fits
  comfortably under that: the "small" 6 tools (BCC/LUA/REGINA/DOJS/GEM/
  TOOLS) together need 17.36MB, FBASIC alone needs 20.14MB, FPC alone
  needs 21.06MB -- none of that mattered for splitting configs anymore
  once QEMU removed the swap-list cap, but it's why 30MB was chosen
  instead of pushing closer to TDSK's absolute max (65534 KB, which very
  much hangs).
  Total guest memory (memsize/-m) is NOT part of this problem and can be
  set as high as you want for CWSDPMI headroom -- that was the original,
  wrong assumption during earlier debugging (that a bigger machine needed
  a bigger memsize to avoid hanging); it's backwards. -m 128 is what's
  used above, giving ~98MB of headroom over the 30MB disk.

Files bigger than one floppy (gdb.exe, fp.exe, ppc386.exe, libstdcx.a,
dojs.exe, libsocket.a, fbc.exe, ogl.DXE, curl.DXE) were split into
NNN-numbered chunks across consecutive disks in that tool's set; the
installer's COPY /B ... reassembles them and deletes the chunks
automatically after copying. Verified the split/rejoin is byte-identical
to the source files before building the images.

TOOLS destination-path fix: TOOLS installs straight to C:\ (not a
subdirectory like the other tools), and its destination path used to come
out as "C:\\" with a doubled backslash, which made every file XCOPY tried
to write fail ("Cannot create destination file", 0 files copied). Fixed by
not giving that one tool's destination path its own trailing backslash
before the installer template adds one.

Name-collision fix: several tools' real executables share their tool's
command name (lua.exe/LUA, bcc.exe/BCC, dojs.exe/DOJS, GEM.EXE/GEM). Once
a tool finishes installing, its C:\<TOOL>.BAT installer deletes itself
(classic self-deleting-batch trick) so the command name resolves to the
real program afterward instead of re-running the installer. This prints a
harmless "Batch file missing" line right after "<TOOL> installed." --
expected, not an error.

Requirements / caveats
  - QEMU needs a floppy controller device, which -fda provides
    automatically for the pc machine type (the default). No other special
    flags are required beyond what's shown above.
  - The DJGPP-built tools (Lua, FPC, DOJS) need free XMS memory at RUNTIME
    for CWSDPMI, separate from whatever TDSK's RAM disk already grabbed.
    With -m 128 and a 30MB RAM disk there's roughly 98MB left over for
    this, which is generous; if you still see "Load error: no DPMI
    memory", something else is eating the guest's XMS.
  - Verified for real: booted BOOT01.img in QEMU (qemu-system-i386 -fda
    BOOT01.img -boot a -m 128), reached the menu in ~20 seconds, typed
    FBASIC, swapped to FBASIC01.img via the monitor's "change floppy0"
    command, and watched it correctly copy real FreeBASIC files
    (FBC.001, part of the split fbc.exe) -- this is a tool/disk
    combination that could never fit in one DOSBox(-X) session before.
    Also separately verified in earlier DOSBox-X testing: LUA installs
    end-to-end (10 real files copied, self-deletes, "LUA -v" afterward
    runs the actual lua.exe instead of re-running the installer, CWSDPMI
    loads), and REGINA installs across all 3 of its disks with correct
    real content (README.TXT, DE.MTB, EN.MTB, EXECISER.EXE, etc.).
  - TDSK.EXE (TurboDSK, freeware, (C) Ciriaco Garcia de Celis), HIMEMX.EXE
    (FreeDOS HIMEM/XMS driver), and the boot-disk copy of CWSDPMI.EXE were
    fetched from ibiblio.org's FreeDOS file archive / taken from the DOJS
    tool tree, and are not originally part of dos8_BASE/EXTRA.
